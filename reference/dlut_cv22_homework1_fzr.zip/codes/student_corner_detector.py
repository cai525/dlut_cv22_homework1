import cv2
import numpy as np
import matplotlib.pyplot as plt
import pdb


def Sobel(image):
    image_X = cv2.Sobel(image, ddepth=cv2.CV_16S, dx=1, dy=0, ksize=3)  # 计算梯度信息，使用高的数据类型
    image_Y = cv2.Sobel(image, ddepth=cv2.CV_16S, dx=0, dy=1, ksize=3)
    return image_X, image_Y


def Construct_cornerness_map(image_xx, image_xy, image_yx, image_yy, image):
    k = 0.04
    w, h = image.shape
    R = np.zeros((w, h))
    for i in range(w):
        for j in range(h):
            M = np.array([[image_xx[i][j], image_xy[i][j]], [image_yx[i][j], image_yy[i][j]]])
            R[i][j] = np.linalg.det(M) - k * np.trace(M) ** 2
    return R


def Non_max_suppression(R, image):
    PointList = []
    threshold = 0.05
    R_max = np.max(R)
    w, h = image.shape
    for i in range(w):
        for j in range(h):
            if R[i, j] > R_max * threshold and R[i, j] == np.max(
                    R[max(0, i - 1):min(i + 2, w - 1), max(0, j - 1):min(j + 2, h - 1)]):
                confidence = R[i][j] / R_max
                PointList.append([j, i, confidence])
    sorted(PointList, key=lambda k: k[2], reverse=True)
    return np.array(PointList)


def get_interest_points(img, feature_width=None):
    """
    For Harris corner detector:
        Implement the Harris corner detector (See Szeliski 4.1.1) to start with.
        You can create additional interest point detector functions (e.g. MSER)
        for extra credit.

        If you're finding spurious interest point detections near the boundaries,
        it is safe to simply suppress the gradients / corners near the edges of
        the image.

        Useful in this function in order to (a) suppress boundary interest
        points (where a feature wouldn't fit entirely in the image, anyway)
        or (b) scale the image filters being used. Or you can ignore it.

        By default you do not need to make scale and orientation invariant
        local features.

        Args:
        -   image: A numpy array of shape (m,n,c),
                    image may be grayscale of color (your choice)
        -   feature_width: (only for Harris) integer representing the local feature width in pixels.

        Returns:
        -   x: A numpy array of shape (N,) containing x-coordinates of interest points
        -   y: A numpy array of shape (N,) containing y-coordinates of interest points
        -   R_sort: A numpy array of shape (N,), descend sorted R,  correspondences to
                    x, y: R_sort[i] =   R[y[i],x[i]]

        please notice that cv2 returns the image with [h,w], which correspondes [y,x] dim respectively.
        ([vertically direction, horizontal direction])

    =================================================================================================
    For LoG detector :

        Implement the LoG corner detector to start with.

        Args:
        -   image: A numpy array of shape (m,n,c),
                    image may be grayscale of color (your choice)

        Returns:
        -   x_sort: A numpy array of shape (N,) containing x-coordinates of interest points
        -   y_sort: A numpy array of shape (N,) containing y-coordinates of interest points
        -   R_sort: A numpy array of shape (N,), descend sorted R,  correspondences to
                    x, y: R_sort[i] =   R[y[i],x[i]]

        The R_sort is the confidence for the selected interest point. If R_sort set to None, the code will
        automatically select the first 100 key points for evaluation,
        in this case, please return x_sort and y_sort with decreasing confidence.

        please notice that cv2 returns the image with [h,w], which correspondes [y,x] dim respectively.
        ([vertically direction, horizontal direction])
    """

    #############################################################################
    # TODO: YOUR HARRIS CORNER DETECTOR CODE HERE                                                      #
    #############################################################################
    image_x, image_y = Sobel(image=img)
    image_xx = image_x ** 2
    image_xy = image_x * image_y
    image_yx = image_y * image_x
    image_yy = image_y ** 2

    kernelsize = (feature_width - 1, feature_width - 1)
    sigma = 2

    image_xx = cv2.GaussianBlur(image_xx, kernelsize, sigma)
    image_xy = cv2.GaussianBlur(image_xy, kernelsize, sigma)
    image_yx = cv2.GaussianBlur(image_yx, kernelsize, sigma)
    image_yy = cv2.GaussianBlur(image_yy, kernelsize, sigma)

    R = Construct_cornerness_map(image_xx, image_xy, image_yx, image_yy, img)

    # raise NotImplementedError('`get_interest_points` function in ' +
    # '`student_harris.py` needs to be implemented')

    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################

    #############################################################################
    # TODO: YOUR ADAPTIVE NON-MAXIMAL SUPPRESSION CODE HERE                     #
    #############################################################################
    PointList = Non_max_suppression(R, img)
    # PointList = PointList[np.argsort(PointList[:,:, 2])]
    x = PointList[:, 0]
    y = PointList[:, 1]
    R_sort = PointList[:, 2]

    # raise NotImplementedError('adaptive non-maximal suppression in ' +
    # '`student_harris.py` needs to be implemented')

    #############################################################################
    #                             END OF YOUR CODE                              #
    #############################################################################
    return x, y, R_sort
